const SYMBOLS = Array.isArray(window.symbols) && window.symbols.length
  ? window.symbols
  : [
      'AALR', 'ABUK', 'ACAMD', 'ACAP', 'ACGC', 'ACRO', 'ACTF', 'ADCI', 'ADIB', 'ADPC',
      'ADRI', 'AFDI', 'AFMC', 'AIDC', 'AIFI', 'AIHC', 'AJWA', 'ALCN', 'ALEX', 'ALUM',
      'AMER', 'AMES', 'AMIA', 'AMII', 'AMOC', 'AMPI', 'APPC', 'APSW', 'ARAB', 'ARCC',
      'AREH', 'ASCM', 'ASPI', 'ATLC', 'ATQA', 'AXPH', 'BIDI', 'BIGP', 'BINV', 'BIOC',
      'BONY', 'BQDC', 'BTFH', 'CAED', 'CANA', 'CCAP', 'CCRS', 'CEFM', 'CERA', 'CFGH',
      'CICH', 'CIEB', 'CIRA', 'CLHO', 'CNFN', 'COMI', 'COPR', 'COSG', 'CPCI', 'CPME',
      'CRST', 'CSAG', 'DAPH', 'DCRC', 'DEIN', 'DGTZ', 'DIFC', 'DOMT', 'DSCW', 'DTPP',
      'EALR', 'EASB', 'EAST', 'EBSC', 'ECAP', 'EDFM', 'EEII', 'EFIC', 'EFID', 'EFIH',
      'EGAL', 'EGAS', 'EGBE', 'EGCH', 'EGREF', 'EGSA', 'EGTS', 'EHDR', 'EITP', 'ELEC',
      'ELKA', 'ELNA', 'ELSH', 'ELWA', 'EMFD', 'ENGC', 'EOSB', 'EPCO', 'EPPK', 'ESAC',
      'ESRS', 'ETEL', 'ETRS', 'EXPA', 'FAIT', 'FAITA', 'FCMD', 'FERC', 'FIRE', 'FNAR',
      'FTNS', 'FWRY', 'GBCO', 'GDWA', 'GGCC', 'GGRN', 'GIHD', 'GMCI', 'GOUR', 'GPIM',
      'GPPL', 'GRCA', 'GSSC', 'GTEX', 'GTHE', 'GTWL', 'HBCO', 'HCFI', 'HDBK', 'HELI',
      'HRHO', 'IBCT', 'ICFC', 'ICID', 'ICLE', 'IDRE', 'IEEC', 'IFAP', 'INEG', 'INFI',
      'IRAX', 'IRON', 'ISMA', 'ISMQ', 'ISPH', 'JUFO', 'KABO', 'KASABF', 'KORA', 'KRDI',
      'KWIN', 'KZPC', 'LCSW', 'LUTS', 'MAAL', 'MASR', 'MBEG', 'MBSC', 'MCQE', 'MCRO',
      'MEGM', 'MENA', 'MEPA', 'MFPC', 'MFSC', 'MHOT', 'MICH', 'MILS', 'MIPH', 'MISR',
      'MKIT', 'MMAT', 'MOED', 'MOIL', 'MOIN', 'MOSC', 'MPCI', 'MPCO', 'MPRC', 'MTIE',
      'NAHO', 'NAPR', 'NARE', 'NBKE', 'NCCW', 'NCGC', 'NDRL', 'NEDA', 'NHPS', 'NINH',
      'NIPH', 'OBRI', 'OCDI', 'OCPH', 'ODIN', 'OFH', 'OIH', 'OLFI', 'ORAS', 'ORHD',
      'ORWE', 'PACH', 'PHAR', 'PHDC', 'PHGC', 'PHTV', 'POUL', 'PRCL', 'PRDC', 'PRMH',
      'QNBE', 'RACC', 'RAKT', 'RAYA', 'RKAZ', 'RMDA', 'RMTV', 'ROTO', 'RREI', 'RTVC',
      'RUBX', 'SAIB', 'SAUD', 'SCEM', 'SCFM', 'SCTS', 'SDTI', 'SEIG', 'SIMO', 'SIPC',
      'SKPC', 'SMFR', 'SMPP', 'SNFC', 'SNFI', 'SPHT', 'SPIN', 'SPMD', 'SUCE', 'SUGR',
      'SVCE', 'SWDY', 'TALM', 'TANM', 'TAQA', 'TMGH', 'TORA', 'TRTO', 'TWSA', 'TYCN',
      'UASG', 'UBEE', 'UEFM', 'UEGC', 'UNIP', 'UNIT', 'UPMS', 'UTOP', 'VALU', 'VERT',
      'VLMR', 'VLMRA', 'WATP', 'WCDF', 'WKOL', 'ZEOT', 'ZMID'
    ];

function getCurrentSymbol() {
  try {
    const url = new URL(window.location.href);
    const symbol = url.searchParams.get('symbol') || '';
    if (symbol) {
      return symbol.replace(/^EGX:/i, '').trim();
    }
  } catch (error) {
    return '';
  }

  const stored = localStorage.getItem('egx-current-symbol');
  return stored || SYMBOLS[0] || '';
}

function getNextSymbol() {
  const current = getCurrentSymbol();
  let index = SYMBOLS.indexOf(current);
  if (index === -1) index = 0;

  const nextIndex = (index + 1) % SYMBOLS.length;
  return SYMBOLS[nextIndex];
}

function updateCurrentSymbol(symbol) {
  localStorage.setItem('egx-current-symbol', symbol);
}

function buildChartUrl(symbol) {
  return `https://www.tradingview.com/chart/Kfdy88ay/?symbol=EGX%3A${encodeURIComponent(symbol)}`;
}

function onSwitch() {
  const nextSymbol = getNextSymbol();
  updateCurrentSymbol(nextSymbol);
  window.location.href = buildChartUrl(nextSymbol);
}

function injectFloatingButton() {
  if (!/^https:\/\/www\.tradingview\.com\//.test(window.location.href)) {
    return;
  }

  if (document.getElementById('egypt-egx-flow-button')) {
    return;
  }

  const button = document.createElement('button');
  button.id = 'egypt-egx-flow-button';
  button.type = 'button';
  button.textContent = 'Switch Stock';
  button.title = 'Switch EGX stock';

  Object.assign(button.style, {
    position: 'fixed',
    right: '18px',
    bottom: '18px',
    zIndex: '999999',
    background: '#1e88ff',
    color: '#fff',
    border: 'none',
    borderRadius: '999px',
    padding: '12px 18px',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    boxShadow: '0 8px 20px rgba(30, 136, 255, 0.35)',
  });

  button.addEventListener('click', onSwitch);
  document.body.appendChild(button);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectFloatingButton, { once: true });
} else {
  injectFloatingButton();
}
